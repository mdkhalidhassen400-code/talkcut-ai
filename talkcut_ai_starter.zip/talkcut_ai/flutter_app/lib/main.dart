import 'dart:async';
import 'package:dio/dio.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const TalkCutApp());

class TalkCutApp extends StatelessWidget {
  const TalkCutApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'TalkCut AI', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6C63FF), brightness: Brightness.dark), useMaterial3: true),
    home: const EditorPage(),
  );
}

class EditorPage extends StatefulWidget {
  const EditorPage({super.key});
  @override
  State<EditorPage> createState() => _EditorPageState();
}

class _EditorPageState extends State<EditorPage> {
  // Android emulator: http://10.0.2.2:8000 ; physical phone: use your computer's LAN IP.
  // Web: http://localhost:8000 when backend is running locally.
  final apiController = TextEditingController(text: 'http://10.0.2.2:8000');
  final startController = TextEditingController(text: '0');
  final endController = TextEditingController(text: '');
  final dio = Dio(BaseOptions(connectTimeout: const Duration(minutes: 10), receiveTimeout: const Duration(minutes: 10), sendTimeout: const Duration(hours: 3)));
  PlatformFile? selected;
  bool useCloud = true;
  bool busy = false;
  double progress = 0;
  String status = 'Choose a video to begin';
  String? jobId;
  String? downloadUrl;
  Timer? poller;

  @override
  void dispose() { poller?.cancel(); apiController.dispose(); startController.dispose(); endController.dispose(); super.dispose(); }

  Future<void> pickVideo() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.video, withData: kIsWeb);
    if (result != null && result.files.isNotEmpty) setState(() { selected = result.files.single; status = 'Video selected: ${selected!.name}'; downloadUrl = null; });
  }

  Future<MultipartFile> toMultipart(PlatformFile file) async {
    if (kIsWeb) {
      final bytes = file.bytes;
      if (bytes == null) throw Exception('Could not read selected file bytes.');
      return MultipartFile.fromBytes(bytes, filename: file.name);
    }
    if (file.path == null) throw Exception('File path unavailable.');
    return MultipartFile.fromFile(file.path!, filename: file.name);
  }

  Future<void> startEdit() async {
    if (selected == null || busy) return;
    if (!useCloud) {
      setState(() => status = 'On-device processing is planned but not enabled in this starter build. Select Cloud for the working MVP.');
      return;
    }
    setState(() { busy = true; progress = 0.03; status = 'Uploading video…'; downloadUrl = null; });
    try {
      final form = FormData.fromMap({
        'video': await toMultipart(selected!),
        'start_seconds': double.tryParse(startController.text) ?? 0,
        'end_seconds': double.tryParse(endController.text) ?? -1,
        'vad_level': 2,
      });
      final base = apiController.text.trim().replaceAll(RegExp(r'/$'), '');
      final response = await dio.post('$base/jobs', data: form, onSendProgress: (sent, total) { if (total > 0 && mounted) setState(() { progress = sent / total * 0.45; status = 'Uploading ${(sent / total * 100).toStringAsFixed(0)}%'; }); });
      jobId = response.data['id'] as String;
      setState(() { progress = 0.5; status = 'AI is detecting speech…'; });
      poller?.cancel();
      poller = Timer.periodic(const Duration(seconds: 4), (_) => checkJob());
      await checkJob();
    } catch (e) {
      setState(() { busy = false; status = 'Error: $e'; });
    }
  }

  Future<void> checkJob() async {
    if (jobId == null) return;
    try {
      final base = apiController.text.trim().replaceAll(RegExp(r'/$'), '');
      final r = await dio.get('$base/jobs/$jobId');
      final data = r.data as Map<String, dynamic>;
      if (!mounted) return;
      setState(() { status = data['message']?.toString() ?? data['status'].toString(); progress = 0.5 + ((data['progress'] as num? ?? 0).toDouble() / 200); });
      if (data['status'] == 'completed') {
        poller?.cancel();
        setState(() { busy = false; progress = 1; downloadUrl = '$base${data['download_url']}'; status = 'Finished! ${data['speech_sections']} speech sections kept.'; });
      } else if (data['status'] == 'failed') {
        poller?.cancel(); setState(() { busy = false; status = 'Processing failed: ${data['message']}'; });
      }
    } catch (e) { if (mounted) setState(() => status = 'Checking job… $e'); }
  }

  Future<void> openDownload() async {
    if (downloadUrl == null) return;
    final uri = Uri.parse(downloadUrl!);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication) && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open download link.')));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('TalkCut AI'), centerTitle: false, actions: const [Padding(padding: EdgeInsets.only(right: 16), child: Icon(Icons.graphic_eq_rounded, color: Color(0xFF9B92FF)))]),
    body: Center(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 720), child: ListView(padding: const EdgeInsets.all(20), children: [
      Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(colors: [Color(0xFF29264D), Color(0xFF171A2B)])), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(Icons.auto_awesome, size: 34, color: Color(0xFFB6AEFF)), SizedBox(height: 12), Text('Keep the speech. Remove the silence.', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)), SizedBox(height: 8), Text('Upload a long video, choose the section you need, and let AI keep the moments when people speak.') ])),
      const SizedBox(height: 20),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('1. Choose your video', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)), const SizedBox(height: 12), OutlinedButton.icon(onPressed: busy ? null : pickVideo, icon: const Icon(Icons.video_library_outlined), label: Text(selected?.name ?? 'Upload video')), if (selected != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text('Size: ${((selected!.size) / (1024 * 1024)).toStringAsFixed(1)} MB', style: Theme.of(context).textTheme.bodySmall))]))),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('2. Select the part to edit', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)), const SizedBox(height: 10), TextField(controller: startController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Start time (seconds)', border: OutlineInputBorder())), const SizedBox(height: 12), TextField(controller: endController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'End time (seconds)', hintText: 'Leave empty to use video end', border: OutlineInputBorder()))]))),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('3. Processing mode', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600)), RadioListTile<bool>(contentPadding: EdgeInsets.zero, value: true, groupValue: useCloud, onChanged: busy ? null : (v) => setState(() => useCloud = v!), title: const Text('Cloud processing (working MVP)'), subtitle: const Text('Best for long videos; needs server and internet')), RadioListTile<bool>(contentPadding: EdgeInsets.zero, value: false, groupValue: useCloud, onChanged: busy ? null : (v) => setState(() => useCloud = v!), title: const Text('On-device processing (coming next)'), subtitle: const Text('Planned for supported phones and browsers'))]))),
      Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('Backend URL', style: TextStyle(fontWeight: FontWeight.w600)), const SizedBox(height: 8), TextField(controller: apiController, decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'http://10.0.2.2:8000'))]))),
      FilledButton.icon(onPressed: selected == null || busy ? null : startEdit, icon: const Icon(Icons.content_cut), label: Text(busy ? 'Processing…' : 'Remove silence with AI'), style: FilledButton.styleFrom(padding: const EdgeInsets.all(16))),
      const SizedBox(height: 16),
      if (busy || progress > 0) LinearProgressIndicator(value: progress.clamp(0, 1)),
      const SizedBox(height: 8), Text(status, textAlign: TextAlign.center),
      if (downloadUrl != null) Padding(padding: const EdgeInsets.only(top: 12), child: FilledButton.tonalIcon(onPressed: openDownload, icon: const Icon(Icons.download), label: const Text('Download edited video'))),
      const SizedBox(height: 24), const Text('Note: This starter version uses cloud speech detection. Local/on-device processing, a visual timeline, resumable uploads, user accounts and production storage are the next development steps.', style: TextStyle(color: Colors.white60, fontSize: 12)),
    ]))),
  );
}
