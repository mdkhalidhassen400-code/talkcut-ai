# TalkCut AI — starter MVP

This starter contains a Flutter Android/Web client and a Python FastAPI backend. The cloud MVP accepts a video, trims to the selected time range, detects speech using WebRTC VAD in 60-second audio chunks, removes non-speech intervals, and exports an MP4.

## Requirements
- Flutter stable (Android + web enabled)
- Python 3.10+
- FFmpeg and ffprobe installed and available on PATH

## Run backend
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```

## Run Flutter
```bash
cd flutter_app
flutter pub get
flutter run -d chrome   # web
flutter run             # Android device/emulator
```

Backend URL in app:
- Android emulator: `http://10.0.2.2:8000`
- Physical Android phone: `http://YOUR_COMPUTER_LAN_IP:8000`
- Web on same computer: `http://localhost:8000`

## Important MVP limitations
- `webrtcvad` is a voice-activity detector, not speaker identification. It keeps speech from any speaker, which matches the initial requirement.
- It may also retain some speech-like noise and can miss very quiet speech. Tune `vad_level` and padding in `backend/main.py` after testing.
- Cloud processing is implemented. The app exposes a planned on-device option but does not claim it works yet; native FFmpeg/VAD integration is a separate platform-specific milestone.
- For multi-hour production uploads, deploy behind authenticated object storage and a task queue (for example S3-compatible storage + Redis/Celery), set upload limits/timeouts, add cleanup, and use resumable/chunked uploads. Do not expose the development server publicly as-is.
- This starter does not yet provide a visual waveform timeline. Start/end selection is entered in seconds.
