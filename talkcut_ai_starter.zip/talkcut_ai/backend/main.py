import os, uuid, shutil, subprocess, threading, wave
from pathlib import Path
from typing import Dict, Any

import webrtcvad
from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse

ROOT = Path(os.getenv("TALKCUT_DATA", "./talkcut_data")).resolve()
ROOT.mkdir(parents=True, exist_ok=True)
JOBS: Dict[str, Dict[str, Any]] = {}
LOCK = threading.Lock()
app = FastAPI(title="TalkCut AI API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=False, allow_methods=["*"], allow_headers=["*"])


def run(cmd):
    p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode:
        raise RuntimeError(p.stderr[-4000:] or "FFmpeg command failed")
    return p


def extract_audio_chunk(video: Path, wav_path: Path, start: float, duration: float):
    run(["ffmpeg", "-y", "-ss", str(start), "-i", str(video), "-t", str(duration), "-vn", "-ac", "1", "-ar", "16000", "-f", "wav", str(wav_path)])


def detect_speech(video: Path, work: Path, vad_level: int = 2):
    """Analyze audio in 60-second chunks; return speech intervals in source-video seconds."""
    probe = run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(video)])
    duration = float(probe.stdout.strip())
    vad = webrtcvad.Vad(vad_level)
    intervals = []
    chunk_seconds = 60
    frame_ms = 30
    frame_bytes = 16000 * frame_ms // 1000 * 2
    total_chunks = int((duration + chunk_seconds - 1) // chunk_seconds)
    for chunk_i in range(total_chunks):
        start = chunk_i * chunk_seconds
        length = min(chunk_seconds, duration - start)
        wav_path = work / f"audio_{chunk_i}.wav"
        extract_audio_chunk(video, wav_path, start, length)
        with wave.open(str(wav_path), "rb") as wf:
            if wf.getframerate() != 16000 or wf.getnchannels() != 1 or wf.getsampwidth() != 2:
                raise RuntimeError("Audio conversion did not produce 16kHz mono PCM")
            raw = wf.readframes(wf.getnframes())
        local = []
        frame_count = len(raw) // frame_bytes
        for i in range(frame_count):
            frame = raw[i * frame_bytes:(i + 1) * frame_bytes]
            if len(frame) == frame_bytes and vad.is_speech(frame, 16000):
                t0 = start + i * frame_ms / 1000
                t1 = t0 + frame_ms / 1000
                if local and t0 - local[-1][1] <= 0.12:
                    local[-1][1] = t1
                else:
                    local.append([t0, t1])
        intervals.extend(local)
        wav_path.unlink(missing_ok=True)
    # Join short pauses and preserve a little context at both ends of speech.
    merged = []
    for a, b in intervals:
        if merged and a - merged[-1][1] <= 0.45:
            merged[-1][1] = b
        else:
            merged.append([a, b])
    padded = [[max(0, a - 0.15), min(duration, b + 0.20)] for a, b in merged]
    # A final merge after padding avoids tiny gaps and duplicate boundaries.
    final = []
    for a, b in padded:
        if final and a <= final[-1][1]: final[-1][1] = max(final[-1][1], b)
        else: final.append([a, b])
    return duration, final


def render_video(source: Path, output: Path, intervals, work: Path):
    if not intervals:
        raise RuntimeError("No speech was detected in the selected video range.")
    concat_file = work / "concat.txt"
    segment_paths = []
    for i, (start, end) in enumerate(intervals):
        seg = work / f"segment_{i:05d}.mp4"
        run(["ffmpeg", "-y", "-ss", f"{start:.3f}", "-i", str(source), "-t", f"{end-start:.3f}", "-map", "0:v:0", "-map", "0:a?", "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(seg)])
        segment_paths.append(seg)
    concat_file.write_text("".join(f"file '{p.as_posix()}'\n" for p in segment_paths), encoding="utf-8")
    run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat_file), "-c", "copy", "-movflags", "+faststart", str(output)])


def process_job(job_id: str, source: Path, start_trim: float, end_trim: float, vad_level: int):
    job_dir = source.parent
    work = job_dir / "work"
    work.mkdir(exist_ok=True)
    try:
        with LOCK: JOBS[job_id].update(status="analyzing", progress=10, message="Analyzing speech")
        # Trim selected range first so user-selected bounds are respected.
        selected = work / "selected.mp4"
        run(["ffmpeg", "-y", "-ss", str(start_trim), "-i", str(source), "-t", str(end_trim-start_trim), "-map", "0", "-c", "copy", str(selected)])
        duration, intervals = detect_speech(selected, work, vad_level)
        with LOCK: JOBS[job_id].update(status="rendering", progress=65, message=f"Found {len(intervals)} speech sections", speech_sections=len(intervals))
        output = job_dir / "talkcut_output.mp4"
        render_video(selected, output, intervals, work)
        with LOCK: JOBS[job_id].update(status="completed", progress=100, message="Ready to download", output=str(output), speech_sections=len(intervals))
    except Exception as e:
        with LOCK: JOBS[job_id].update(status="failed", progress=0, message=str(e))


@app.get("/health")
def health(): return {"ok": True, "service": "TalkCut AI"}

@app.post("/jobs")
async def create_job(background_tasks: BackgroundTasks, video: UploadFile = File(...), start_seconds: float = 0, end_seconds: float = -1, vad_level: int = 2):
    if not video.filename: raise HTTPException(400, "Missing filename")
    job_id = str(uuid.uuid4())
    job_dir = ROOT / job_id
    job_dir.mkdir(parents=True)
    suffix = Path(video.filename).suffix.lower() or ".mp4"
    source = job_dir / f"source{suffix}"
    try:
        with source.open("wb") as out:
            while True:
                chunk = await video.read(8 * 1024 * 1024)
                if not chunk: break
                out.write(chunk)
    except Exception:
        shutil.rmtree(job_dir, ignore_errors=True); raise
    probe = run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", str(source)])
    duration = float(probe.stdout.strip())
    actual_end = duration if end_seconds < 0 else min(end_seconds, duration)
    if start_seconds < 0 or actual_end <= start_seconds:
        shutil.rmtree(job_dir, ignore_errors=True)
        raise HTTPException(400, "Invalid selected time range")
    JOBS[job_id] = {"id": job_id, "status": "queued", "progress": 0, "message": "Queued", "duration_seconds": duration}
    background_tasks.add_task(process_job, job_id, source, start_seconds, actual_end, max(0, min(3, vad_level)))
    return JOBS[job_id]

@app.get("/jobs/{job_id}")
def get_job(job_id: str):
    if job_id not in JOBS: raise HTTPException(404, "Job not found")
    job = dict(JOBS[job_id]); job.pop("output", None)
    if job.get("status") == "completed": job["download_url"] = f"/jobs/{job_id}/download"
    return job

@app.get("/jobs/{job_id}/download")
def download_job(job_id: str):
    job = JOBS.get(job_id)
    if not job or job.get("status") != "completed": raise HTTPException(404, "Output not ready")
    return FileResponse(job["output"], media_type="video/mp4", filename="talkcut_output.mp4")
